import './App.css';
import AppLayout from './component/Applayout/Applayout';

function App() {
  return (
    <AppLayout/>
  );
}

export default App;

export const PREVIOUS_ARROW = "https://amasa-files.s3.us-west-2.amazonaws.com/arrow-previous.svg"
export const NEXT_ARROW = "https://amasa-files.s3.us-west-2.amazonaws.com/arrow-next.svg"
export const NO_IMAGE = "https://amasa-files.s3.us-west-2.amazonaws.com/no_image.jpg"